from distutils.core import setup


setup(
    name='TistoryHelper',
    version='1.0.0',
    packages=['src'],
    url='',
    license='MIT style',
    author='adunstudio',
    author_email='',
    description='',
    install_requires=["Flask"],
)
